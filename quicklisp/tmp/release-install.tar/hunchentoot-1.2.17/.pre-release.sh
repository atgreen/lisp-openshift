cd doc; make
